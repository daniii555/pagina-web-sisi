import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.Executors;

public class Main {
  private static final Path ROOT = Path.of("web").toAbsolutePath().normalize();
  private static final Map<String,String> TYPES = Map.of(
    "html", "text/html; charset=UTF-8",
    "css", "text/css; charset=UTF-8",
    "js", "application/javascript; charset=UTF-8",
    "png", "image/png",
    "jpg", "image/jpeg",
    "svg", "image/svg+xml",
    "json", "application/json; charset=UTF-8"
  );
  public static void main(String[] args) throws Exception {
    int port;
    try { port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080")); }
    catch(NumberFormatException e){ port = 8080; }
    HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
    server.createContext("/", Main::handle);
    server.setExecutor(Executors.newFixedThreadPool(8));
    server.start();
    System.out.println("UTMACH Orienta listo en http://localhost:" + port);
  }
  private static void handle(HttpExchange ex) throws IOException {
    String method = ex.getRequestMethod();
    if(ex.getRequestURI().getPath().equals("/api/telemetry")){ telemetry(ex); return; }
    if(!method.equals("GET") && !method.equals("HEAD")) {
      reply(ex,405,"text/plain; charset=UTF-8","Método no admitido".getBytes(StandardCharsets.UTF_8)); return;
    }
    String req = ex.getRequestURI().getPath();
    if(req.equals("/api/lan")) { reply(ex,200,"application/json; charset=UTF-8",("{\"ip\":\""+lanIp()+"\"}").getBytes(StandardCharsets.UTF_8)); return; }
    if(req.equals("/health")) { reply(ex,200,"text/plain; charset=UTF-8","ok".getBytes(StandardCharsets.UTF_8)); return; }
    String requested = req.equals("/") ? "index.html" : req.substring(1);
    Path file = ROOT.resolve(requested).normalize();
    if(!file.startsWith(ROOT) || !Files.isRegularFile(file)) {
      reply(ex,404,"text/plain; charset=UTF-8","No encontrado".getBytes(StandardCharsets.UTF_8)); return;
    }
    String name=file.getFileName().toString();
    String ext=name.contains(".")?name.substring(name.lastIndexOf('.')+1).toLowerCase():"";
    byte[] b=Files.readAllBytes(file);
    ex.getResponseHeaders().set("Cache-Control","no-cache, max-age=0");
    ex.getResponseHeaders().set("X-Content-Type-Options","nosniff");
    reply(ex,200,TYPES.getOrDefault(ext,"application/octet-stream"),b);
  }
  private static final java.util.regex.Pattern FRAME = java.util.regex.Pattern.compile("^STATE:(IDLE|ROUTE|DONE|ERROR)\\|([^|]{0,23})\\|([01]{7})\\|([01]{2})\\|([^|]{16})\\|([^|]{16})$");
  private static final java.util.ArrayDeque<String> HISTORY = new java.util.ArrayDeque<>();
  private static String current = "null";
  private static long receivedAt = 0;
  private static String lastFrame = "";
  private static long lastHistory = 0;
  private static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
  private static synchronized void telemetry(HttpExchange ex) throws IOException {
    ex.getResponseHeaders().set("Cache-Control","no-store");
    String method=ex.getRequestMethod();
    if(method.equals("POST")){
      String token=System.getenv().getOrDefault("TELEMETRY_TOKEN", "");
      String auth=ex.getRequestHeaders().getFirst("Authorization");
      boolean allowed=token.isEmpty() ? ex.getRemoteAddress().getAddress().isLoopbackAddress() && ("localhost".equalsIgnoreCase(ex.getRequestHeaders().getFirst("Host")) || ex.getRequestHeaders().getFirst("Host").startsWith("localhost:") || ex.getRequestHeaders().getFirst("Host").startsWith("127.0.0.1:")) : ("Bearer "+token).equals(auth);
      String origin=ex.getRequestHeaders().getFirst("Origin");
      if(origin!=null && !origin.equals("http://"+ex.getRequestHeaders().getFirst("Host")) && !origin.equals("https://"+ex.getRequestHeaders().getFirst("Host"))) allowed=false;
      if(!allowed){reply(ex,403,"text/plain",new byte[0]);return;}
      String frame=new String(ex.getRequestBody().readNBytes(256),StandardCharsets.US_ASCII);
      var m=FRAME.matcher(frame);
      if(!m.matches() || frame.chars().anyMatch(c->c<32||c>126)){reply(ex,400,"text/plain",new byte[0]);return;}
      long now=System.currentTimeMillis();receivedAt=now;
      current="{\"time\":"+quote(java.time.Instant.ofEpochMilli(now).toString())+",\"state\":"+quote(m.group(1))+",\"dest\":"+quote(m.group(2))+",\"led\":"+quote(m.group(3))+",\"buzz\":"+quote(m.group(4))+",\"lcd\":["+quote(m.group(5))+","+quote(m.group(6))+"],\"line\":"+quote(frame)+"}";
      if(!frame.equals(lastFrame)||now-lastHistory>=5000){HISTORY.addFirst(current);while(HISTORY.size()>100)HISTORY.removeLast();lastFrame=frame;lastHistory=now;}
      reply(ex,200,"text/plain", "ok".getBytes(StandardCharsets.UTF_8));return;
    }
    if(!method.equals("GET")){reply(ex,405,"text/plain",new byte[0]);return;}
    String json="{\"live\":"+(receivedAt>0&&System.currentTimeMillis()-receivedAt<4500)+",\"current\":"+current+",\"history\":["+String.join(",",HISTORY)+"]}";
    reply(ex,200,"application/json; charset=UTF-8",json.getBytes(StandardCharsets.UTF_8));
  }
  // IP de la laptop en la red local (para que el QR funcione desde el celular estando en localhost)
  private static String lanIp(){
    try{
      String fallback="";
      var en=java.net.NetworkInterface.getNetworkInterfaces();
      while(en!=null && en.hasMoreElements()){
        var ni=en.nextElement();
        if(!ni.isUp()||ni.isLoopback()) continue;
        String n=ni.getDisplayName().toLowerCase();
        boolean virt=ni.isVirtual()||n.contains("virtual")||n.contains("vmware")||n.contains("vbox")||n.contains("hyper-v")||n.contains("wsl")||n.contains("docker");
        for(var a:java.util.Collections.list(ni.getInetAddresses())){
          if(a instanceof java.net.Inet4Address && a.isSiteLocalAddress()){ if(virt) fallback=a.getHostAddress(); else return a.getHostAddress(); }
        }
      }
      return fallback;
    }catch(Exception e){ return ""; }
  }
  private static void reply(HttpExchange ex,int code,String type,byte[] bytes)throws IOException{
    ex.getResponseHeaders().set("Content-Type",type);
    if(ex.getRequestMethod().equals("HEAD")) {
      ex.sendResponseHeaders(code,-1);
    } else {
      ex.sendResponseHeaders(code,bytes.length);
      try(var out=ex.getResponseBody()){out.write(bytes);}
    }
    ex.close();
  }
}
